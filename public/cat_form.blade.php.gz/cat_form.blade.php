@extends('layouts.admin')
@section('title', isset($category->id) ? 'Edit Category' : 'New Category')
@section('breadcrumb')
    <a href="{{ route('admin.categories.index') }}" style="color:var(--a-muted)">Categories</a>
    <span style="margin:0 .5rem;color:var(--a-muted)">/</span>
    <span>{{ isset($category->id) ? 'Edit' : 'New' }}</span>
@endsection

@section('content')
<div class="page-title">{{ isset($category->id) ? 'Edit Category' : 'Add Category' }}</div>

<form action="{{ isset($category->id) ? route('admin.categories.update', $category) : route('admin.categories.store') }}" method="POST" enctype="multipart/form-data">
    @csrf
    @if(isset($category->id)) @method('PUT') @endif

    <div style="display:grid;grid-template-columns:1fr 300px;gap:1.25rem">
        <div class="form-card">
            <div class="f-group">
                <label class="f-label">Name *</label>
                <input type="text" name="name" class="f-control" value="{{ old('name', $category->name) }}" required>
            </div>
            <div class="f-group">
                <label class="f-label">Description</label>
                <textarea name="description" class="f-control" rows="3">{{ old('description', $category->description) }}</textarea>
            </div>
            <div class="f-group">
                <label class="f-label">Parent Category</label>
                <select name="parent_id" class="f-control">
                    <option value="">— None (Top Level / Main Category) —</option>
                    @foreach($parents as $parent)
                    <option value="{{ $parent->id }}" {{ old('parent_id', $category->parent_id) == $parent->id ? 'selected' : '' }}>
                        {{ $parent->name }}
                    </option>
                    @endforeach
                </select>
                <small style="color:var(--a-muted);font-size:.73rem">Leave blank to make this a main category shown on the homepage.</small>
            </div>
            <div class="f-row">
                <div class="f-group">
                    <label class="f-label">Icon (Emoji)</label>
                    <input type="text" name="icon" class="f-control" value="{{ old('icon', $category->icon) }}" placeholder="🌿">
                </div>
                <div class="f-group">
                    <label class="f-label">Sort Order</label>
                    <input type="number" name="sort_order" class="f-control" value="{{ old('sort_order', $category->sort_order ?? 0) }}" min="0">
                </div>
            </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:1.25rem">
            <div class="form-card">
                <div class="form-section-title">Image</div>
                @if(isset($category->id) && $category->image)
                    <img src="{{ asset('storage/'.$category->image) }}" id="img-preview" class="img-preview">
                @else
                    <div class="img-preview-placeholder" id="img-preview-placeholder">📁</div>
                    <img id="img-preview" class="img-preview" style="display:none">
                @endif
                <input type="file" name="image" accept="image/*" data-preview="img-preview" style="margin-top:.75rem;font-size:.8rem;color:var(--a-muted)">
            </div>
            <div class="form-card">
                <div class="toggle-wrap">
                    <label class="toggle">
                        <input type="checkbox" name="status" value="1" {{ old('status', $category->status ?? true) ? 'checked' : '' }}>
                        <span class="toggle-slider"></span>
                    </label>
                    <span>Active</span>
                </div>
            </div>
            <div style="display:flex;gap:.75rem">
                <button type="submit" class="a-btn a-btn-primary" style="flex:1;justify-content:center">Save</button>
                <a href="{{ route('admin.categories.index') }}" class="a-btn a-btn-ghost">Cancel</a>
            </div>
        </div>
    </div>
</form>
@endsection
