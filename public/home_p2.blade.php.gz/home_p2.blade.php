{{-- ── Collections ── --}}
@if($collections->count())
<section class="section collections">
    <div class="container">
        <div class="section-head section-head-flex">
            <div>
                <span class="section-label">Handpicked for Global Markets</span>
                <h2 class="section-title">Featured Export Collections</h2>
                <p class="section-sub">Curated collections loved by our global import partners</p>
            </div>
        </div>
        <div class="coll-grid">
            @foreach($collections as $coll)
            <div class="coll-card">
                <div class="coll-img">
                    @if($coll->image)
                        <img src="{{ asset('storage/'.$coll->image) }}" alt="{{ $coll->name }}" loading="lazy" class="coll-bg-img">
                    @else
                        <div class="coll-img-placeholder">🌿</div>
                    @endif
                    <div class="coll-overlay">
                        <div class="coll-name">{{ $coll->name }}</div>
                        <p class="coll-desc">{{ $coll->description }}</p>
                        <a href="{{ route('products.index') }}" class="coll-btn">Explore Now</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif

{{-- ── Products ── --}}
<section class="section products-section">
    <div class="container">
        <div class="products-tab-hd">
            <h2 class="section-title section-title-flush">Our Products</h2>
            <a href="{{ route('products.index') }}" class="view-all-link view-all-push">View All Products
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
        <div class="products-carousel-wrap">
            <button class="pc-arrow pc-prev" id="pcPrev" aria-label="Previous products">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
            </button>
            <div class="products-carousel" id="home-products">
                @foreach($featured as $product)
                @include('partials.product-card', ['product' => $product])
                @endforeach
            </div>
            <button class="pc-arrow pc-next" id="pcNext" aria-label="Next products">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
        </div>
    </div>
</section>
<script>
(function(){
    var carousel = document.getElementById('home-products');
    if(!carousel) return;
    var prev = document.getElementById('pcPrev');
    var next = document.getElementById('pcNext');
    function getStep(){
        var card = carousel.querySelector('.product-card');
        if(!card) return 300;
        var gap = parseFloat(getComputedStyle(carousel).gap) || 20;
        return (card.offsetWidth + gap) * 2;
    }
    prev && prev.addEventListener('click', function(){ carousel.scrollBy({left:-getStep(),behavior:'smooth'}); });
    next && next.addEventListener('click', function(){ carousel.scrollBy({left: getStep(),behavior:'smooth'}); });
    function update(){
        if(!prev || !next) return;
        prev.disabled = carousel.scrollLeft <= 4;
        next.disabled = carousel.scrollLeft >= carousel.scrollWidth - carousel.clientWidth - 4;
    }
    carousel.addEventListener('scroll', update, {passive:true});
    update();
    var sx = null;
    carousel.addEventListener('pointerdown', function(e){ if(e.pointerType==='mouse') return; sx=e.clientX; }, {passive:true});
    carousel.addEventListener('pointerup', function(e){
        if(sx===null||e.pointerType==='mouse') return;
        var dx=e.clientX-sx; sx=null;
        if(Math.abs(dx)<40) return;
        carousel.scrollBy({left: dx<0?getStep():-getStep(), behavior:'smooth'});
    }, {passive:true});
})();
</script>

{{-- ── Why Import ── --}}
<section class="why-import-section">
    <div class="wi-left">
        <div class="wi-left-inner">
            <span class="section-label">Why Sri Lanka?</span>
            <h2 class="wi-heading">Why Import<br>From Sri Lanka?</h2>
            <p class="wi-desc">Sri Lanka offers some of the world's finest agricultural products with unmatched quality and consistency.</p>
            <a href="{{ route('about') }}" class="btn btn-primary wi-btn">
                Discover More
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
        <div class="wi-map">
            <img src="/images/import-section.webp" alt="Sri Lanka Map" loading="lazy">
        </div>
    </div>
    <div class="wi-right">
        <div class="wi-feat-col">
            <div class="wi-feat-icon wi-icon-cinnamon">
                <svg width="40" height="40" viewBox="0 0 48 48" fill="none"><rect x="8" y="20" width="6" height="24" rx="3" fill="#C8922A" transform="rotate(-15 8 20)"/><rect x="16" y="16" width="6" height="28" rx="3" fill="#b07826" transform="rotate(-10 16 16)"/><rect x="24" y="14" width="6" height="28" rx="3" fill="#C8922A" transform="rotate(-5 24 14)"/></svg>
            </div>
            <div class="wi-feat-title">Finest Ceylon<br>Cinnamon</div>
            <div class="wi-feat-desc">The best quality cinnamon in the world</div>
        </div>
        <div class="wi-feat-divider"></div>
        <div class="wi-feat-col">
            <div class="wi-feat-icon wi-icon-sun">
                <svg width="40" height="40" viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="10" fill="#C8922A" opacity=".9"/><line x1="24" y1="4" x2="24" y2="10" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="24" y1="38" x2="24" y2="44" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="4" y1="24" x2="10" y2="24" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="38" y1="24" x2="44" y2="24" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="9.37" y1="9.37" x2="13.6" y2="13.6" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="34.4" y1="34.4" x2="38.63" y2="38.63" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="38.63" y1="9.37" x2="34.4" y2="13.6" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/><line x1="13.6" y1="34.4" x2="9.37" y2="38.63" stroke="#C8922A" stroke-width="3" stroke-linecap="round"/></svg>
            </div>
            <div class="wi-feat-title">Rich Tropical<br>Climate</div>
            <div class="wi-feat-desc">Ideal for growing premium products</div>
        </div>
        <div class="wi-feat-divider"></div>
        <div class="wi-feat-col">
            <div class="wi-feat-icon wi-icon-leaf">
                <svg width="40" height="40" viewBox="0 0 48 48" fill="none"><path d="M24 40C24 40 8 30 8 18C8 11.373 15.373 6 24 6C32.627 6 40 11.373 40 18C40 30 24 40 24 40Z" fill="#1B4332" opacity=".15"/><path d="M24 40C24 40 8 30 8 18C8 11.373 15.373 6 24 6C32.627 6 40 11.373 40 18C40 30 24 40 24 40Z" stroke="#1B4332" stroke-width="2" fill="none"/><path d="M24 40V20" stroke="#1B4332" stroke-width="2" stroke-linecap="round"/><path d="M14 24C18 22 24 22 24 20" stroke="#1B4332" stroke-width="1.5" stroke-linecap="round"/><path d="M34 18C30 18 24 20 24 20" stroke="#1B4332" stroke-width="1.5" stroke-linecap="round"/></svg>
            </div>
            <div class="wi-feat-title">Sustainable<br>Farming</div>
            <div class="wi-feat-desc">Environment friendly farming practices</div>
        </div>
        <div class="wi-feat-divider"></div>
        <div class="wi-feat-col">
            <div class="wi-feat-icon wi-icon-shield">
                <svg width="40" height="40" viewBox="0 0 48 48" fill="none"><path d="M24 6L8 12V24C8 32 15.5 39 24 42C32.5 39 40 32 40 24V12L24 6Z" fill="#1B4332" opacity=".1"/><path d="M24 6L8 12V24C8 32 15.5 39 24 42C32.5 39 40 32 40 24V12L24 6Z" stroke="#1B4332" stroke-width="2" fill="none"/><polyline points="17 24 22 29 32 18" stroke="#1B4332" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
            </div>
            <div class="wi-feat-title">Export<br>Standards</div>
            <div class="wi-feat-desc">Comply with global quality standards</div>
        </div>
    </div>
</section>
