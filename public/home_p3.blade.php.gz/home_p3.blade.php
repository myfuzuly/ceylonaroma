{{-- ── Discover Coffee CTA ── --}}
<section class="coffee-cta-section">
    <div class="coffee-cta-inner">
        <div class="coffee-cta-text">
            <h2 class="coffee-cta-heading">
                Discover Authentic<br>
                <em>Ceylon Coffee</em>
            </h2>
            <p class="coffee-cta-desc">Grown in the misty highlands of Sri Lanka.<br>Rich flavor, smooth taste.</p>
            <a href="{{ route('products.index', ['category' => 'ceylon-coffee']) }}" class="coffee-cta-btn">
                Discover Coffee
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
    </div>
</section>

{{-- ── Export Process ── --}}
<section class="section export-process">
    <div class="container">
        <div class="section-head center section-head-xl">
            <span class="section-label">How It Works</span>
            <h2 class="section-title">Our Export Process</h2>
            <p class="section-sub">From our farms to your hands — with rigorous quality control at every step</p>
        </div>
        <div class="process-row">
            <div class="process-line"></div>
            @foreach([
                ['01','Sourcing','We work directly with vetted farmers across Sri Lanka\'s finest growing regions, ensuring traceability from soil to shipment.','<path d="M12 2C7 2 3 7 4 13c.8 4.5 4.5 8 8 9 3.5-1 7.2-4.5 8-9 1-6-3-11-8-11z"/>'],
                ['02','Processing','Raw produce is cleaned, dried, and processed using modern technology while preserving natural oils and active compounds.','<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>'],
                ['03','Quality Check','Every batch undergoes laboratory testing for purity, moisture, and microbial standards — meeting ISO and international certifications.','<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>'],
                ['04','Packaging','Custom hygienic packaging in your preferred format — bulk, retail, or private label — with compliant labelling for your market.','<path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>'],
                ['05','Export','Full documentation, customs clearance support, and on-time delivery to 60+ countries — your order arrives safely, every time.','<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>'],
            ] as [$num, $title, $desc, $svg])
            <div class="process-step-wrap">
                <div class="process-icon-wrap">
                    <div class="process-icon-circle">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">{!! $svg !!}</svg>
                    </div>
                </div>
                <div class="process-num">{{ $num }}</div>
                <div class="process-title">{{ $title }}</div>
                <p class="process-desc">{{ $desc }}</p>
            </div>
            @endforeach
        </div>
    </div>
</section>

{{-- ── Testimonials (hidden — review later) ── --}}
{{-- <section class="section testimonials-section"> --}}
@if(false)<section class="section testimonials-section">
    <div class="container">
        <div class="section-head center">
            <span class="section-label">What Importers Say</span>
            <h2 class="section-title">Trusted by Global Buyers</h2>
            <p class="section-sub">Real feedback from importers across 60+ countries who partner with us year after year</p>
        </div>
        <div class="testi-grid">
            <div class="testi-card reveal">
                <div class="testi-stars">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <blockquote class="testi-quote">"We've been importing Ceylon cinnamon and black pepper from Ceylon Aroma for six years. The consistency in quality is outstanding — every shipment passes our EU certification checks without issue."</blockquote>
                <div class="testi-author">
                    <div class="testi-flag">🇩🇪</div>
                    <div>
                        <div class="testi-name">Klaus Meier</div>
                        <div class="testi-role">Import Director, BioSpice GmbH — Germany</div>
                    </div>
                </div>
            </div>
            <div class="testi-card reveal reveal-delay-1">
                <div class="testi-stars">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <blockquote class="testi-quote">"Their private label service saved us 4 months of sourcing time. The Ceylon tea we import is selling brilliantly in our premium retail chain. Reliable partner, transparent documentation."</blockquote>
                <div class="testi-author">
                    <div class="testi-flag">🇦🇺</div>
                    <div>
                        <div class="testi-name">Sarah O'Brien</div>
                        <div class="testi-role">Procurement Head, NaturePure Co. — Australia</div>
                    </div>
                </div>
            </div>
            <div class="testi-card reveal reveal-delay-2">
                <div class="testi-stars">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                </div>
                <blockquote class="testi-quote">"From inquiry to delivery, the team at Ceylon Aroma is professional and responsive. We import cloves, cardamom, and vanilla — all impeccably packed and HACCP certified. Highly recommended."</blockquote>
                <div class="testi-author">
                    <div class="testi-flag">🇯🇵</div>
                    <div>
                        <div class="testi-name">Hiroshi Tanaka</div>
                        <div class="testi-role">Supply Chain Manager, Nakamura Foods — Japan</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>@endif

{{-- ── Knowledge Centre ── --}}
@if($posts->count())
<section class="section knowledge">
    <div class="container">
        <div class="knowledge-hd">
            <div>
                <span class="section-label">Insights &amp; Expertise</span>
                <h2 class="section-title section-title-flush">Knowledge Center</h2>
            </div>
            <a href="{{ route('blog.index') }}" class="view-all-link">View All Articles
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
        <div class="blog-grid">
            @foreach($posts as $post)
            <article class="blog-card">
                <a href="{{ route('blog.show', $post->slug) }}">
                    <div class="blog-img">
                        @if($post->image)
                            <img src="{{ asset('storage/'.$post->image) }}" alt="{{ $post->title }}" loading="lazy">
                        @else
                            <div class="blog-img-placeholder">📖</div>
                        @endif
                        @if($post->category)<span class="blog-cat">{{ $post->category }}</span>@endif
                    </div>
                </a>
                <div class="blog-body">
                    <div class="blog-meta">{{ $post->published_at?->format('M d, Y') }}</div>
                    <h3 class="blog-title"><a href="{{ route('blog.show', $post->slug) }}">{{ $post->title }}</a></h3>
                    <p class="blog-excerpt">{{ $post->excerpt }}</p>
                </div>
            </article>
            @endforeach
        </div>
    </div>
</section>
@endif
