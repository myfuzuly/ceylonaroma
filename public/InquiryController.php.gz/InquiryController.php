<?php

namespace App\Http\Controllers;

use App\Models\Inquiry;
use App\Models\Category;
use Illuminate\Http\Request;

class InquiryController extends Controller
{
    public function show()
    {
        $categories = Category::whereNull('parent_id')->where('status', true)->orderBy('sort_order')->get();
        return view('pages.contact', compact('categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'    => 'required|string|max:255',
            'email'   => 'required|email|max:255',
            'phone'   => 'nullable|string|max:50',
            'company' => 'nullable|string|max:255',
            'country' => 'nullable|string|max:100',
            'message' => 'nullable|string|max:2000',
        ]);

        Inquiry::create([
            ...$validated,
            'products' => $request->products ?? [],
            'status'   => 'new',
        ]);

        return back()->with('success', 'Thank you! Your inquiry has been received. We will contact you shortly.');
    }
}
