{{-- ── Pre-footer CTA Strip ── --}}
<section class="footer-cta-strip">
    <div class="container">
        <div class="footer-cta-inner">
            <div class="footer-cta-text">
                <h3>Ready to Import Premium Ceylon Products?</h3>
                <p>Partner with us for certified, high-quality natural products trusted by importers in 60+ countries worldwide.</p>
            </div>
            <div class="footer-cta-actions">
                <a href="{{ route('contact') }}" class="btn btn-gold">
                    Request Export Quote
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
                <a href="tel:+94718821234" class="btn btn-outline-white">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2A19.79 19.79 0 013.09 5.18 2 2 0 015.09 3h3a2 2 0 012 1.72c.127.96.36 1.903.7 2.81a2 2 0 01-.45 2.11L9.09 11a16 16 0 006.91 6.91l1.27-1.27a2 2 0 012.11-.45c.907.34 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                    +94 71 882 1234
                </a>
            </div>
        </div>
    </div>
</section>

{{-- ── Footer ── --}}
<footer class="footer" role="contentinfo">
    <div class="footer-top">
        <div class="container">
            <div class="footer-grid-5">
                {{-- Brand --}}
                <div class="footer-brand">
                    <a href="{{ route('home') }}" class="logo" aria-label="Ceylon Aroma Home">
                        <img src="/images/ceylonaroma3.png" alt="Ceylon Aroma" class="logo-img logo-img-footer">
                    </a>
                    <p class="footer-tagline">We are a leading exporter of premium quality spices, tea, coffee, oils and natural products from Sri Lanka.</p>
                    <div class="footer-socials">
                        <a href="{{ $settings['facebook_url'] ?? '#' }}" class="footer-social" target="_blank" rel="noopener" aria-label="Facebook"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg></a>
                        <a href="{{ $settings['instagram_url'] ?? '#' }}" class="footer-social" target="_blank" rel="noopener" aria-label="Instagram"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg></a>
                        <a href="{{ $settings['linkedin_url'] ?? '#' }}" class="footer-social" target="_blank" rel="noopener" aria-label="LinkedIn"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/></svg></a>
                        <a href="{{ $settings['youtube_url'] ?? '#' }}" class="footer-social" target="_blank" rel="noopener" aria-label="YouTube"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M22.54 6.42a2.78 2.78 0 00-1.95-1.97C18.88 4 12 4 12 4s-6.88 0-8.59.45A2.78 2.78 0 001.46 6.42 29 29 0 001 12a29 29 0 00.46 5.58A2.78 2.78 0 003.41 19.6C5.12 20 12 20 12 20s6.88 0 8.59-.4a2.78 2.78 0 001.95-1.97A29 29 0 0023 12a29 29 0 00-.46-5.58z"/><polygon points="9.75 15.02 15.5 12 9.75 8.98 9.75 15.02" fill="#0F2920"/></svg></a>
                    </div>
                    <div class="cert-logos">
                        <span class="cert-badge">ISO 9001</span>
                        <span class="cert-badge">HACCP</span>
                        <span class="cert-badge">USDA Organic</span>
                        <span class="cert-badge">NOP</span>
                    </div>
                </div>
                {{-- Products --}}
                <div class="footer-col">
                    <h5>Products</h5>
                    <div class="footer-links">
                        <a href="{{ route('products.index') }}?category=ceylon-spices">Ceylon Spices</a>
                        <a href="{{ route('products.index') }}?category=ceylon-coffee">Ceylon Coffee</a>
                        <a href="{{ route('products.index') }}?category=ceylon-tea">Ceylon Tea</a>
                        <a href="{{ route('products.index') }}?category=aromatic-oils">Aromatic Oils</a>
                        <a href="{{ route('products.index') }}?category=frozen-pulp">Frozen Pulp</a>
                        <a href="{{ route('products.index') }}?category=dehydrated-products">Dehydrated Products</a>
                        <a href="{{ route('products.index') }}?category=nuts-natural-foods">Nuts &amp; Natural Foods</a>
                    </div>
                </div>
                {{-- Company --}}
                <div class="footer-col">
                    <h5>Company</h5>
                    <div class="footer-links">
                        <a href="{{ route('about') }}">About Us</a>
                        <a href="{{ route('about') }}">Our Story</a>
                        <a href="{{ route('quality') }}">Quality Assurance</a>
                        <a href="{{ route('quality') }}">Our Certifications</a>
                        <a href="{{ route('about') }}">Sustainability</a>
                        <a href="{{ route('contact') }}">Careers</a>
                        <a href="{{ route('contact') }}">Contact Us</a>
                    </div>
                </div>
                {{-- Export --}}
                <div class="footer-col">
                    <h5>Export</h5>
                    <div class="footer-links">
                        <a href="{{ route('export') }}">Export Process</a>
                        <a href="{{ route('about') }}">Why Sri Lanka</a>
                        <a href="{{ route('quality') }}">Our Certifications</a>
                        <a href="{{ route('export') }}">Shipping &amp; Delivery</a>
                        <a href="{{ route('private-label') }}">Private Label</a>
                        <a href="{{ route('contact') }}">Terms &amp; Conditions</a>
                    </div>
                </div>
                {{-- Contact --}}
                <div class="footer-col">
                    <h5>Contact Us</h5>
                    <div class="footer-contact-item">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <span>{{ $settings['site_address'] ?? 'No: F – 05, New City Building, Nidahas Mawatha, Kegalle, Sri Lanka' }}</span>
                    </div>
                    <div class="footer-contact-item">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2A19.79 19.79 0 013.09 5.18 2 2 0 015.09 3h3a2 2 0 012 1.72c.127.96.36 1.903.7 2.81a2 2 0 01-.45 2.11L9.09 11a16 16 0 006.91 6.91l1.27-1.27a2 2 0 012.11-.45c.907.34 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                        <span><a href="tel:+94718821234" class="footer-tel">+94 71 882 1234</a> (Mobile / WhatsApp)</span>
                    </div>
                    <div class="footer-contact-item">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 01-2.18 2A19.79 19.79 0 013.09 5.18 2 2 0 015.09 3h3a2 2 0 012 1.72c.127.96.36 1.903.7 2.81a2 2 0 01-.45 2.11L9.09 11a16 16 0 006.91 6.91l1.27-1.27a2 2 0 012.11-.45c.907.34 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                        <span><a href="tel:+94354341234" class="footer-tel">+94 35 434 1234</a> (Landline)</span>
                    </div>
                    <div class="footer-contact-item">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                        <span>{{ $settings['site_email'] ?? 'info@ceylonaroma.com' }}</span>
                    </div>
                    <div class="footer-contact-cta">
                        <a href="{{ route('contact') }}" class="btn btn-gold btn-sm">Request a Quote</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="footer-bottom">
            <span>&copy; {{ date('Y') }} {{ $settings['site_name'] ?? 'Ceylon Aroma' }} (Pvt) Ltd. All Rights Reserved.</span>
            <span class="footer-credit">Conceived &amp; Crafted by <a href="https://fidhaps.com" target="_blank" rel="noopener" class="footer-credit-link">FIDHAPS</a></span>
            <div class="footer-bottom-links">
                <a href="#">Privacy Policy</a>
                <a href="#">Terms &amp; Conditions</a>
            </div>
        </div>
    </div>
</footer>

@stack('scripts')
</body>
</html>
