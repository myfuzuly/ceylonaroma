{{-- ── Discover Coffee CTA ── --}}
<section class="section cta-section">
    <div class="container" style="position:relative;z-index:2">
        <div class="coffee-grid">
            <div>
                <span class="section-label" style="color:var(--gold-2)">Pure Ceylon Coffee</span>
                <h2 style="color:#fff;margin-bottom:.75rem">Discover Authentic<br><em style="font-style:italic;color:var(--gold-2)">Ceylon Coffee</em></h2>
                <p style="color:rgba(255,255,255,.75);max-width:38ch;margin-bottom:1.5rem">Grown in the misty highlands of Sri Lanka. Rich flavor, smooth taste, harvested sustainably.</p>
                <a href="{{ route('products.index', ['category' => 'ceylon-coffee']) }}" class="btn btn-gold">Discover Coffee
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
            </div>
        </div>
    </div>
</section>

{{-- ── Export Process ── --}}
<section class="section export-process">
    <div class="container">
        <div class="section-head center" style="margin-bottom:3rem">
            <span class="section-label">How It Works</span>
            <h2 class="section-title">Our Export Process</h2>
            <p class="section-sub">From our farms to your hands — with rigorous quality control at every step</p>
        </div>
        <div class="process-row">
            <div class="process-line"></div>
            @foreach([
                ['01','Sourcing','Carefully selected from trusted farmers','<path d="M12 2C7 2 3 7 4 13c.8 4.5 4.5 8 8 9 3.5-1 7.2-4.5 8-9 1-6-3-11-8-11z"/>'],
                ['02','Processing','Cleaned &amp; processed with modern technology','<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>'],
                ['03','Quality Check','Strict quality control to ensure purity','<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>'],
                ['04','Packaging','Hygienic &amp; premium packaging solutions','<path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>'],
                ['05','Export','Delivered to your country safely &amp; on time','<rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>'],
            ] as $step)
            <div class="process-step-wrap">
                <div class="process-icon-circle">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">{!! $step[3] !!}</svg>
                </div>
                <div class="process-num">{{ $step[0] }}</div>
                <div class="process-title">{{ $step[1] }}</div>
                <p class="process-desc">{!! $step[2] !!}</p>
            </div>
            @endforeach
        </div>
    </div>
</section>

{{-- ── Knowledge Centre ── --}}
@if($posts->count())
<section class="section knowledge">
    <div class="container">
        <div class="knowledge-hd">
            <div>
                <span class="section-label">Insights &amp; Expertise</span>
                <h2 class="section-title" style="margin:0">Knowledge Center</h2>
            </div>
            <a href="{{ route('blog.index') }}" class="view-all-link">View All Articles
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
        </div>
        <div class="blog-grid">
            @foreach($posts as $post)
            <article class="blog-card">
                <a href="{{ route('blog.show', $post->slug) }}">
                    <div class="blog-img">
                        @if($post->image)
                            <img src="{{ asset('storage/'.$post->image) }}" alt="{{ $post->title }}" loading="lazy">
                        @else
                            <div class="blog-img-placeholder">📖</div>
                        @endif
                        @if($post->category)<span class="blog-cat">{{ $post->category }}</span>@endif
                    </div>
                </a>
                <div class="blog-body">
                    <div class="blog-meta">{{ $post->published_at?->format('M d, Y') }}</div>
                    <h3 class="blog-title"><a href="{{ route('blog.show', $post->slug) }}">{{ $post->title }}</a></h3>
                    <p class="blog-excerpt">{{ $post->excerpt }}</p>
                </div>
            </article>
            @endforeach
        </div>
    </div>
</section>
@endif
