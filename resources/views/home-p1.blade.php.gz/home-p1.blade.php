{{-- ── Hero — Split: static text left, image slider right ── --}}
<section class="hero hero-split" id="heroSection">
    <div class="hero-split-wrap">

        {{-- LEFT: Static text --}}
        <div class="hero-split-left">
            <div class="hero-split-text">
                <h1 class="hero-title">
                    Delivering the<br>
                    Natural <em>Taste &amp; Aroma</em><br>
                    of Sri Lanka to the World
                </h1>
                <p class="hero-desc">
                    Premium quality spices, tea, coffee, oils and natural
                    products sourced from the rich lands of Sri Lanka
                    for a healthier and better tomorrow.
                </p>
                <div class="hero-cta">
                    <a href="{{ route('products.index') }}" class="btn btn-primary">
                        Explore Products
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                    <a href="{{ route('contact') }}" class="btn btn-outline">
                        Export Inquiry
                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>
        </div>

        {{-- RIGHT: Image slider --}}
        <div class="hero-split-right" id="hsRight">

            {{-- Slides --}}
            <div class="hs-slides">
                @forelse($slides as $i => $slide)
                <div class="hs-slide{{ $i === 0 ? ' active' : '' }}" data-index="{{ $i }}">
                    <img src="{{ asset('storage/'.$slide->image) }}"
                         alt="{{ $slide->title ?? 'Ceylon Aroma' }}"
                         loading="{{ $i === 0 ? 'eager' : 'lazy' }}">
                </div>
                @empty
                <div class="hs-slide active">
                    <img src="/images/hero-visual.webp" alt="Ceylon Aroma Premium Products" loading="eager">
                </div>
                @endforelse
            </div>

            {{-- Left cream-fade: blends image into text background --}}
            <div class="hs-fade"></div>

            {{-- 100% Pure Ceylon Goodness badge --}}
            <div class="hero-purity-badge">
                <div class="hpb-ring"></div>
                <div class="hpb-pct">100%</div>
                <div class="hpb-label">Pure Ceylon<br>Goodness</div>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" style="color:var(--gold,#b98a37)"><path d="M12 2C7 2 3 7 4 13c.8 4.5 4.5 8 8 9 3.5-1 7.2-4.5 8-9 1-6-3-11-8-11z"/></svg>
            </div>

            {{-- Dot nav --}}
            @if($slides->count() > 1)
            <div class="hs-dots" id="hsDots">
                @foreach($slides as $i => $slide)
                <button class="hs-dot{{ $i === 0 ? ' active' : '' }}"
                        data-index="{{ $i }}"
                        aria-label="Slide {{ $i + 1 }}"></button>
                @endforeach
            </div>
            @endif

        </div>{{-- /.hero-split-right --}}
    </div>{{-- /.hero-split-wrap --}}
</section>

{{-- Slider JS --}}
@if($slides->count() > 1)
<script>
(function(){
    var slides = Array.from(document.querySelectorAll('.hs-slide'));
    var dots   = Array.from(document.querySelectorAll('.hs-dot'));
    var n = slides.length, cur = 0, DUR = 5500, timer = null;
    if(n < 2) return;

    function go(i){
        slides[cur].classList.remove('active');
        dots[cur] && dots[cur].classList.remove('active');
        cur = (i + n) % n;
        slides[cur].classList.add('active');
        dots[cur] && dots[cur].classList.add('active');
    }

    function play(){ timer = setInterval(function(){ go(cur + 1); }, DUR); }
    function pause(){ clearInterval(timer); }

    play();

    dots.forEach(function(d, i){
        d.addEventListener('click', function(){ pause(); go(i); play(); });
    });

    // Touch swipe on right panel
    var sx = null;
    var el = document.getElementById('hsRight');
    el.addEventListener('pointerdown', function(e){ if(e.pointerType==='mouse') return; sx=e.clientX; }, {passive:true});
    el.addEventListener('pointerup',   function(e){
        if(sx===null||e.pointerType==='mouse') return;
        var dx = e.clientX - sx; sx = null;
        if(Math.abs(dx) < 40) return;
        pause(); go(dx < 0 ? cur+1 : cur-1); play();
    }, {passive:true});
})();
</script>
@endif

{{-- ── Stats Bar ── --}}
<div class="stats-bar">
    <div class="stats-inner">
        <div class="stat-item">
            <div class="stat-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg></div>
            <div class="stat-num">{{ $settings['stat_countries'] ?? '60+' }}</div>
            <div class="stat-label">Countries Exported</div>
        </div>
        <div class="stat-item">
            <div class="stat-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg></div>
            <div class="stat-num">{{ $settings['stat_products'] ?? '500+' }}</div>
            <div class="stat-label">Premium Products</div>
        </div>
        <div class="stat-item">
            <div class="stat-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg></div>
            <div class="stat-num">{{ $settings['stat_years'] ?? '15+' }}</div>
            <div class="stat-label">Years of Excellence</div>
        </div>
        <div class="stat-item">
            <div class="stat-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2"><path d="M12 2C7 2 3 7 4 13c.8 4.5 4.5 8 8 9 3.5-1 7.2-4.5 8-9 1-6-3-11-8-11z"/></svg></div>
            <div class="stat-num">100%</div>
            <div class="stat-label">Natural &amp; Pure</div>
        </div>
        <div class="stat-item">
            <div class="stat-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.9)" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
            <div class="stat-num">Certified</div>
            <div class="stat-label">Quality Assured</div>
        </div>
    </div>
</div>

{{-- ── Categories ── --}}
<section class="section categories">
    <div class="container">
        <div class="section-head center">
            <span class="section-label">What We Export</span>
            <h2 class="section-title">Our Product Categories</h2>
            <p class="section-sub">A wide range of certified natural products sourced from Sri Lanka</p>
        </div>
        <div class="cat-grid">
            @foreach($categories as $cat)
            <a href="{{ route('products.index', ['category' => $cat->slug]) }}" class="cat-card">
                @if($cat->image)
                    <div class="cat-img-wrap">
                        <img src="{{ asset('storage/'.$cat->image) }}" alt="{{ $cat->name }}" loading="lazy">
                    </div>
                @else
                    @php $eicons=['Ceylon Spices'=>'🌶️','Ceylon Coffee'=>'☕','Ceylon Tea'=>'🍵','Aromatic Oils'=>'🫙','Pulp'=>'🍋','Dehydrated Products'=>'🌿','Dates & Nuts'=>'🥜','Ayurvedic Products'=>'🌱','Lifestyle & Natural Care'=>'✨','Ceylon Cinnamon'=>'🍂']; @endphp
                    <div class="cat-img-placeholder">{{ $eicons[$cat->name] ?? '🌿' }}</div>
                @endif
                <span class="cat-name">{{ $cat->name }}</span>
            </a>
            @endforeach
        </div>
    </div>
</section>

{{-- ── Why Choose ── --}}
<section class="section why-choose">
    <div class="container">
        <div class="section-head center">
            <span class="section-label">Our Advantage</span>
            <h2 class="section-title">Why Choose Ceylon Aroma?</h2>
        </div>
        <div class="why-choose-row">
            @foreach([
                ['<path d="M12 2C7 2 3 7 4 13c.8 4.5 4.5 8 8 9 3.5-1 7.2-4.5 8-9 1-6-3-11-8-11z"/>','Sri Lankan Origin'],
                ['<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>','Export Quality'],
                ['<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>','Sustainable Sourcing'],
                ['<path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/>','Premium Packaging'],
                ['<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>','Global Delivery'],
                ['<path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/>','Direct Farmer Network'],
            ] as $pill)
            <div class="why-pill">
                <div class="why-pill-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">{!! $pill[0] !!}</svg>
                </div>
                <div class="why-pill-label">{{ $pill[1] }}</div>
            </div>
            @endforeach
        </div>
    </div>
</section>
